//
//  URL+Assets.swift
//  MasterThesis
//
//  Created by Lukas Sestic on 10.04.2021..
//

import Foundation

extension URL {

    static let assetsDirectory = URL(string: "/Users/lukassestic/Developer/MasterThesis/Assets")!
}
