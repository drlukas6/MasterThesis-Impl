//
//  UInt8+Colors.swift
//  MasterThesis
//
//  Created by Lukas Sestic on 10.04.2021..
//

import Foundation

extension UInt8 {

    static let black = UInt8(0)
    static let white = UInt8(255)
}
