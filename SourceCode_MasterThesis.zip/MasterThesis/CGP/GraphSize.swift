//
//  GraphSize.swift
//  MasterThesis
//
//  Created by Lukas Sestic on 17.02.2021..
//
